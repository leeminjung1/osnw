#include <stdio.h>
extern void name();
void id() {
	printf("32172988\t");
	name();
}
