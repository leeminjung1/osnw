#include <stdio.h>
extern void id();
void main() {
	printf("OSNW\t");
	id();
}
